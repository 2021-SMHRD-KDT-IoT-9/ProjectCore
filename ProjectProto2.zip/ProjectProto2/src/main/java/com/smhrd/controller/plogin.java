package com.smhrd.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.smhrd.model.pMemberDAO;
import com.smhrd.model.pMemberVO;

@WebServlet("/plogin")
public class plogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		System.out.println(id);
		System.out.println(pwd);
		
		pMemberDAO dao = new pMemberDAO();
		
		pMemberVO vo = new pMemberVO(id, pwd);
		List<pMemberVO> list = dao.plogin(vo);
		


		if (list == null) { 
			System.out.println("로그인 실패...");
			response.sendRedirect("main.jsp");
		} else { 
			System.out.println("로그인 성공!");
			HttpSession session = request.getSession();
		    session.setAttribute("id", id);
		    session.setAttribute("pwd", pwd);
		    response.sendRedirect("main2.jsp");
		}		
	}
}