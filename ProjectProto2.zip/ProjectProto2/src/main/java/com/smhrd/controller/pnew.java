package com.smhrd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.smhrd.model.pMemberDAO;
import com.smhrd.model.pMemberVO;

@WebServlet("/pnew")
public class pnew extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String consentName = request.getParameter("consentName");
		String consentId = request.getParameter("consentId");
		String icon = request.getParameter("icon");
		String wait = request.getParameter("wait");

		System.out.println(id);
		System.out.println(pwd);
		System.out.println(consentName);
		System.out.println(consentId);
		System.out.println(icon);
		System.out.println(wait);

		pMemberVO vo = new pMemberVO(id, pwd, consentName, consentId, icon, wait);

		pMemberDAO dao = new pMemberDAO();
		int cnt = dao.pjoin(vo);

		if (cnt > 0) {
			System.out.println("회원가입 성공!");
			response.sendRedirect("main.jsp");
		} else {
			System.out.println("회원가입 실패...");
			response.sendRedirect("main.jsp");
		}
	}
}
