package com.smhrd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.model.pMemberDAO;
import com.smhrd.model.pMemberVO;
import com.smhrd.model.pScheduleDAO;
import com.smhrd.model.pScheduleVO;

@WebServlet("/pschedule")
public class pschedule extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(); // 세션 가져오기
		String memid = (String) session.getAttribute("id"); // 세션에서 "user" 속성 가져오기

		String conid = request.getParameter("conid");
		String date = request.getParameter("date");
		String time = request.getParameter("time");
		String onoff = request.getParameter("onoff");
		String message = request.getParameter("message");

		System.out.println(memid);
		System.out.println(conid);
		System.out.println(date);
		System.out.println(time);
		System.out.println(onoff);
		System.out.println(message);
		
		pScheduleVO vo = new pScheduleVO(memid, conid, date, time, message, onoff);
		pScheduleDAO dao = new pScheduleDAO();
		int cnt = dao.p_schedule(vo);

		if (cnt > 0) {
			System.out.println("스케줄등록 성공!");
			response.sendRedirect("success.jsp");
		} else {
			System.out.println("스케줄등록 실패...");
			response.sendRedirect("main2.jsp");
		}
		
		

	}

}
