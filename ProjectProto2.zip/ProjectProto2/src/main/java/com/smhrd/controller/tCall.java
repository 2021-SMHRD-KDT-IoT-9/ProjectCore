package com.smhrd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.smhrd.controller.tOnoff.MyMqtt_Pub_Client;


@WebServlet("/tCall")
public class tCall extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String a_conid = (String) request.getAttribute("a_conid");
        String a_onoff = (String) request.getAttribute("a_onoff");
        
        System.out.println("a_conid: " + a_conid);
        System.out.println("a_onoff: " + a_onoff);
        

		MyMqtt_Pub_Client sender = new MyMqtt_Pub_Client();
		String msg = "{conid:" + a_conid + ",relayValue:"+a_onoff+"}";
		sender.send(msg);

	}

	public class MyMqtt_Pub_Client {
		// MQTT통신에서 publisher와 Subscriber의 역할을 하기 위한 기	능을 가진 객체
		private MqttClient client;

		public MyMqtt_Pub_Client() {

			try {
				// broker와 MQTT통신을 하며 메세지를 전송할 클라이언트 객체를 만들고 접속
				client = new MqttClient("tcp://119.200.31.252:8883", ""); // broker 서버
				client.connect();// broker접속
				System.out.println("success");
			} catch (MqttException e) {
				e.printStackTrace();
				System.out.println("fail...");
			}
		}

		// 메세지 전송을 위한 메소드
		public boolean send(String msg) {
			try {
				// broker로 전송할 메세지 생성 -MqttMessage
				MqttMessage message = new MqttMessage();
				message.setPayload(msg.getBytes()); // 실제 broker로 전송할 메세지
				client.publish("conRelay", message);
				System.out.println("success2");
			} catch (MqttException e) {
				e.printStackTrace();
				System.out.println("fail...");
			}
			return true;
		}

		public void close() {
			if (client != null) {
				try {
					client.disconnect();
					client.close();
				} catch (MqttException e) {
					e.printStackTrace();
				}
			}
		}

	}
}