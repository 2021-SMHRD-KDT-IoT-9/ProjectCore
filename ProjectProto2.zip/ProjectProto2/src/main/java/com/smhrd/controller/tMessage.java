package com.smhrd.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.smhrd.model.pMessageDAO;
import com.smhrd.model.pMessageVO;

@WebServlet("/tMessage")
public class tMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String a_conid="1";
		String a_date="1";
		String a_time="1";
		String a_message="1";

		request.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(); // 세션 가져오기
		String memid = (String) session.getAttribute("id"); // 세션에서 "user" 속성 가져오기
		String p_check = "N";
		

		a_conid = (String) request.getAttribute("a_conid");
		a_date = (String) request.getAttribute("a_date");
		a_time = (String) request.getAttribute("a_time");
		a_message = (String) request.getAttribute("a_message");
		
		System.out.println("메시지는" + a_message);
		
		pMessageVO vo = new pMessageVO(memid, a_conid, a_date, a_conid, a_message, p_check);
		pMessageDAO dao = new pMessageDAO();
		int cnt = dao.p_message(vo);
		
		if (cnt > 0) {
			System.out.println("메시지 등록 성공!");
			response.sendRedirect("main2.jsp");
		} else {
			System.out.println("메시지 등록 실패...");
			response.sendRedirect("main2.jsp");
		}
	}
}
