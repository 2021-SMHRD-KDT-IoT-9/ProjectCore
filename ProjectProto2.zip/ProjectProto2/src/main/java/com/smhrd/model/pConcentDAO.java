package com.smhrd.model;

import java.util.List;
import java.util.Date;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.smhrd.db.SqlSessionManager;

public class pConcentDAO {
	
	private static SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSessionFactory();
	
	public List<pConcentVO> pconcent(String conid) {
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pConcentVO> list = session.selectList("pconcent",conid);
		session.close();
		return list;
	}
	
	public List<pConcentVO> pconcent2(String conid) {
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pConcentVO> list = session.selectList("pconcent2",conid);
		session.close();
		return list;
	}

}
