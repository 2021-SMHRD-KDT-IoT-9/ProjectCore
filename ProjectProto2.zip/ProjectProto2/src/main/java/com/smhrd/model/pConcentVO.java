package com.smhrd.model;

import java.math.BigDecimal;
import java.util.Date;

public class pConcentVO {
	
	private String conid; 
    private Date p_date;
    private BigDecimal energy;
    private String p_state;
    
	public pConcentVO(String conid, Date p_date, BigDecimal energy, String p_state) {
		super();
		this.conid = conid;
		this.p_date = p_date;
		this.energy = energy;
		this.p_state = p_state;
	}
	
	public pConcentVO(String conid) {
		this.conid = conid;
	}

	public String getConid() {
		return conid;
	}

	public Date getP_date() {
		return p_date;
	}

	public BigDecimal getEnergy() {
		return energy;
	}

	public String getP_state() {
		return p_state;
	}
    
    

}
