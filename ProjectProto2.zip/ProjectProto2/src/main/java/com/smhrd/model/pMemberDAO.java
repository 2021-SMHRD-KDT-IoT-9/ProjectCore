package com.smhrd.model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.smhrd.db.SqlSessionManager;

public class pMemberDAO {

	private static SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSessionFactory();

	// 회원가입
	public int pjoin(pMemberVO vo) {
		SqlSession session = sqlSessionFactory.openSession(true);
		int cnt = session.insert("pjoin", vo);
		session.close();
		return cnt;
	}

	// 로그인
	public List<pMemberVO> plogin(pMemberVO vo) {
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pMemberVO> list = session.selectList("plogin", vo);
		session.close();
		return list;
	}
	
	// 콘센트 리스트
	public List<pMemberVO> clist(pMemberVO vo) {
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pMemberVO> list = session.selectList("clist", vo);
		session.close();
		return list;
	}
	
}
