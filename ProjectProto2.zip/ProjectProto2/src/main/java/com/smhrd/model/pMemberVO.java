package com.smhrd.model;

public class pMemberVO {
	
	private String memid;
	private String mempw;
	private String connick;
	private String conid;
	private String icon;
	private String wait;
	
	public pMemberVO(String memid, String mempw, String connick, String conid, String icon, String wait) {
		super();
		this.memid = memid;
		this.mempw = mempw;
		this.connick = connick;
		this.conid = conid;
		this.icon = icon;
		this.wait = wait;
	}
	
	public pMemberVO(String memid, String mempw) {
		this.memid = memid;
		this.mempw = mempw;
	}
	
	public pMemberVO(String memid, String mempw, String someOtherParameter) {
	    this.memid = memid;
	    this.mempw = mempw;
	}

	public String getMemid() {
		return memid;
	}

	public String getMempw() {
		return mempw;
	}

	public String getConnick() {
		return connick;
	}

	public String getConid() {
		return conid;
	}

	public String getIcon() {
		return icon;
	}

	public String getWait() {
		return wait;
	}
	
	

}
