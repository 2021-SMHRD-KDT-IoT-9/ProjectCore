package com.smhrd.model;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.smhrd.db.SqlSessionManager;

public class pMessageDAO {
	
	private static SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSessionFactory();
	
	// 메시지 등록
	public int p_message(pMessageVO vo) {
		SqlSession session = sqlSessionFactory.openSession(true);
		// true는 오토커밋, 기본값은 false임
		int cnt = session.insert("p_message", vo);
		session.close();
		return cnt;
	}


	// 메시지 불러오기(확인) 
	public List<pMessageVO> ca_message(){
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pMessageVO> list = session.selectList("ca_message");
		session.close();
		return list;
	}

}
