package com.smhrd.model;

public class pMessageVO {
	
	private String memid;
	private String conid;
	private String p_date;
	private String p_time;
	private String message;
	private String p_check;
	
	public pMessageVO(String memid, String conid, String p_date, String p_time, String message, String p_check) {
		super();
		this.memid = memid;
		this.conid = conid;
		this.p_date = p_date;
		this.p_time = p_time;
		this.message = message;
		this.p_check = p_check;
	}
	public String getMemid() {
		return memid;
	}
	public String getConid() {
		return conid;
	}
	public String getP_date() {
		return p_date;
	}
	public String getP_time() {
		return p_time;
	}
	public String getMessage() {
		return message;
	}
	public String getP_check() {
		return p_check;
	}

}
