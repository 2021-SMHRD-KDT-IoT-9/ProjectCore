package com.smhrd.model;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.smhrd.db.SqlSessionManager;

public class pScheduleDAO {

	private static SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSessionFactory();
	
	//스케줄 등록
	public int p_schedule(pScheduleVO vo) {
		SqlSession session = sqlSessionFactory.openSession(true);
		int cnt = session.insert("p_schedule", vo);
		session.close();
		return cnt;
	}

	// 스케줄 불러오기(확인) 
	public List<pScheduleVO> p_scheduleAll(){
		SqlSession session = sqlSessionFactory.openSession(true);
		List<pScheduleVO> list = session.selectList("p_scheduleAll");
		session.close();
		return list;
	}
	
}