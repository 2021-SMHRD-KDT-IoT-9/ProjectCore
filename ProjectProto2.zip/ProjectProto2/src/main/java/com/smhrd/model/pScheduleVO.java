package com.smhrd.model;

public class pScheduleVO {

	private String memid;
	private String conid;
	private String p_date;
	private String p_time;
	private String message;
	private String onoff;
	
	public pScheduleVO(String memid, String conid, String p_date, String p_time, String message, String onoff) {
		super();
		this.memid = memid;
		this.conid = conid;
		this.p_date = p_date;
		this.p_time = p_time;
		this.message = message;
		this.onoff = onoff;
	}

	public String getMemid() {
		return memid;
	}

	public String getConid() {
		return conid;
	}

	public String getP_date() {
		return p_date;
	}

	public String getP_time() {
		return p_time;
	}

	public String getMessage() {
		return message;
	}

	public String getOnoff() {
		return onoff;
	}
	
	

	
}
